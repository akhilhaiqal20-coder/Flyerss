package com.flyerss.signal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101D2D)
private val Panel2 = Color(0xFF15243A)
private val Gold = Color(0xFFE3B83F)
private val Green = Color(0xFF20D69A)
private val Red = Color(0xFFFF456B)
private val Cyan = Color(0xFF42D9F5)
private val Purple = Color(0xFF9B82FF)
private val Muted = Color(0xFF91A0B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FlyerssApp() }
    }
}

@Composable
fun FlyerssApp() {
    var selected by remember { mutableStateOf("Signal") }
    var price by remember { mutableStateOf<Double?>(null) }
    var status by remember { mutableStateOf("Connecting…") }
    var updated by remember { mutableStateOf("Waiting for first update") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun refreshPrice() {
        try {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("https://flyerss-signal-api.prohunterkhil08.workers.dev/price")
                .get().build()
            val response = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                client.newCall(request).execute().use { r ->
                    if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                    r.body?.string() ?: throw IllegalStateException("Empty response")
                }
            }
            val json = JSONObject(response)
            val found = findPrice(json)
            if (found == null) throw IllegalStateException("Price field not found in API response")
            price = found
            status = "LIVE DATA CONNECTED"
            updated = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())
            error = null
        } catch (e: Exception) {
            status = "CONNECTION ERROR"
            error = e.message ?: "Unable to fetch market price"
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            refreshPrice()
            delay(15_000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Navy)) {
            Header(status, onRefresh = { scope.launch { refreshPrice() } })
            when (selected) {
                "Signal" -> SignalPage(price, updated, error)
                "Statistics" -> InfoPage("STATISTICS", "Signal statistics will appear after validated candle-based signals have been recorded.", listOf("Win rate — not available yet", "TP1 / TP2 / TP3 — not available yet", "Historical performance — awaiting verified signals"))
                "Analysis" -> InfoPage("TECHNICAL ANALYSIS", "The current API supplies a spot price only. Technical analysis requires verified OHLC candle data.", listOf("Support & Resistance", "FVG and liquidity", "QM and market structure", "Heikin Ashi and momentum", "Multi-timeframe confirmation"))
                "Screener" -> ScreenerPage()
                "AI News" -> InfoPage("AI NEWS", "News feed is not connected yet. No headlines are fabricated.", listOf("Connect a trusted economic-news provider to enable this page."))
                else -> InfoPage("MORE", "FLYERSS SIGNAL settings", listOf("Instrument: XAUUSD", "Refresh interval: 15 seconds", "Mode: Live market data", "Signal mode: Safe / no fabricated setups"))
            }
            Spacer(Modifier.weight(1f))
            BottomBar(selected) { selected = it }
        }
    }
}

private fun findPrice(o: JSONObject): Double? {
    val candidates = listOf("price", "spot_usd_oz", "last", "close")
    if (o.has("xau") && o.optJSONObject("xau") != null) {
        val nested = o.getJSONObject("xau")
        for (key in candidates) if (nested.has(key)) return nested.optDouble(key).takeIf { it > 0.0 }
    }
    for (key in candidates) if (o.has(key)) return o.optDouble(key).takeIf { it > 0.0 }
    val keys = o.keys()
    while (keys.hasNext()) {
        val key = keys.next()
        val nested = o.optJSONObject(key) ?: continue
        for (candidate in candidates) if (nested.has(candidate))
            return nested.optDouble(candidate).takeIf { it > 0.0 }
    }
    return null
}

@Composable
fun Header(status: String, onRefresh: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF050B13)).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("FLYERSS", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("SIGNAL", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(if (status.contains("CONNECTED")) Green else Gold, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(status, color = if (status.contains("CONNECTED")) Green else Gold, fontSize = 10.sp)
            }
        }
        Text("XAUUSD", color = Cyan, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = Gold) }
    }
}

@Composable
fun SignalPage(price: Double?, updated: String, error: String?) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF34445A), RoundedCornerShape(18.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ModeChip("SCALPING", true)
                Spacer(Modifier.width(8.dp))
                ModeChip("INTRADAY", false)
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("NEXT", color = Muted, fontSize = 10.sp)
                    Text("--:--", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp))
                    .border(1.dp, Color(0xFF4A4B43), RoundedCornerShape(22.dp)).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("XAUUSD · SCALPING", color = Gold, letterSpacing = 2.sp, fontSize = 12.sp)
                        Text("Waiting for validated setup", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Surface(color = Muted.copy(alpha = .15f), shape = RoundedCornerShape(30.dp)) {
                        Text("NO TRADE", color = Muted, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("LIVE PRICE", color = Muted, letterSpacing = 2.sp, fontSize = 11.sp)
                Text(price?.let { String.format(Locale.US, "%.2f", it) } ?: "— — —", color = Cyan, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Text("Last updated: $updated", color = Muted, fontSize = 11.sp)
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text("Market data issue: $error", color = Red, fontSize = 12.sp)
                }
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("SL", "ENTRY", "TP1", "TP2", "TP3").forEachIndexed { i, label ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(9.dp).background(if (i == 0) Red else Muted.copy(alpha = .45f), CircleShape))
                            Text(label, color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Surface(color = Color(0xFF132B2A), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("NO TRADE · DATA VALIDATION", color = Green, fontWeight = FontWeight.Bold)
                            Text("Live spot price is available, but verified candle data is required before calculating signals.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("TRADING GRID", color = Gold, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                listOf("ENTRY", "STOP LOSS", "TP1", "TP2", "TP3").forEach {
                    Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(it, color = Gold, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("—", color = Color.White, fontSize = 18.sp)
                        Spacer(Modifier.width(12.dp))
                        Icon(Icons.Default.ContentCopy, null, tint = Muted, modifier = Modifier.size(18.dp))
                    }
                    HorizontalDivider(color = Color(0xFF28364A))
                }
                Text("No entry levels until a setup is validated.", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("BEFORE YOU ENTER", color = Purple, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Signals are analytical information, not guarantees. Confirm risk and market conditions independently.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ModeChip(text: String, active: Boolean) {
    Surface(color = if (active) Gold else Panel2, shape = RoundedCornerShape(30.dp)) {
        Text(text, color = if (active) Navy else Muted, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun ScreenerPage() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("TIMEFRAME SCREENER", color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(14.dp))
        listOf("M1", "M5", "M15", "M30", "H1", "H4").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Awaiting candle data", color = Muted, fontSize = 12.sp)
                Text("—", color = Gold)
            }
        }
        Text("No timeframe bias is shown without verified OHLC data.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun InfoPage(title: String, subtitle: String, items: List<String>) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(title, color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 18.sp)
        Spacer(Modifier.height(10.dp))
        Text(subtitle, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        items.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) {
                Text("•  $item", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    val items = listOf(
        "Signal" to Icons.Default.ShowChart,
        "Statistics" to Icons.Default.BarChart,
        "Analysis" to Icons.Default.Tune,
        "Screener" to Icons.Default.GridView,
        "AI News" to Icons.Default.Newspaper,
        "More" to Icons.Default.Person
    )
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF050B13)).padding(horizontal = 4.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (label, icon) ->
            val active = selected == label
            Column(
                Modifier.weight(1f).clickable { onSelect(label) }
                    .background(if (active) Gold else Color.Transparent, RoundedCornerShape(24.dp))
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, null, tint = if (active) Navy else Muted, modifier = Modifier.size(20.dp))
                Text(label, color = if (active) Navy else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
