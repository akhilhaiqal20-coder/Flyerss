# FLYERSS SIGNAL — Android starter project

This is a native Android/Kotlin + Jetpack Compose starter app.

## Included
- Dark mobile dashboard inspired by the supplied reference.
- XAUUSD spot-price polling from the configured Cloudflare Worker endpoint.
- Connection/error status and last-update time.
- Signal progress and trading grid UI.
- Bottom navigation: Signal, Statistics, Analysis, Screener, AI News, More.
- GitHub Actions workflow to build a debug APK in the cloud.

## Important market-data limitation
The configured `/price` endpoint provides a spot price. A single spot price is not enough to calculate SNR, FVG, liquidity sweeps, QM, Heikin Ashi, market structure, momentum, or multi-timeframe confirmation. Therefore the app deliberately displays **NO TRADE** and does not invent Entry/SL/TP levels.

To enable validated signals, add a trusted OHLC candle endpoint that returns timestamped open, high, low, close and volume data for XAUUSD at M1, M5, M15, M30, H1 and H4. Then implement and test the signal engine against that data. Do not treat the current spot endpoint as candle history.

## Build in the cloud using a phone
1. Create a new GitHub repository named `flyerss-signal`.
2. Upload the contents of this ZIP to the repository root (keep folder structure).
3. Open the repository's **Actions** tab.
4. Select **Build FLYERSS SIGNAL APK** and tap **Run workflow**.
5. When the run completes, open it and download the `FLYERSS-SIGNAL-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Build locally
Requires JDK 17 and Android SDK 35:
`gradle assembleDebug`

## Notes
- This is a debug APK for testing, not a Play Store release.
- Android 13+ requires notification permission; notification scheduling is not implemented in this starter.
- No broker connection or real-money trade execution is included.
- The API response parser accepts common `price` and `xau.price` response shapes; adjust it if your worker response differs.
